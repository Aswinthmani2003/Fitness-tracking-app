const calculateBtn = document.getElementById('calculate-btn');

calculateBtn.addEventListener('click', function() {
  const weight = parseFloat(document.getElementById('weight').value);
  const height = parseFloat(document.getElementById('height').value);

  if (isNaN(weight) || isNaN(height)) {
    alert('Please enter valid weight and height.');
    return;
  }

  const bmi = weight / (height / 100) ** 2;

  let bmiCategory;
  if (bmi < 18.5) {
    bmiCategory = 'Underweight';
  } else if (bmi >= 18.5 && bmi <= 24.9) {
    bmiCategory = 'Normal weight';
  } else if (bmi >= 25 && bmi <= 29.9) {
    bmiCategory = 'Overweight';
  } else if (bmi == 0) {
    bmiCategory = 'Invalid input';
  } else {
    bmiCategory = 'Obese';
  }

  alert(`Your BMI is: ${bmi.toFixed(2)}\nBMI Category: ${bmiCategory}`);
});
