const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/fitness", { useNewUrlParser: true, useUnifiedTopology: true });

// Define a schema and model for the gym collection
const gymSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
});

const Gym = mongoose.model("Gym", gymSchema);

// Serve the signup form
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/js/signup.html");
});

// Handle form submission
app.post("/signup", (req, res) => {
  const newUser = new Gym({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password
  });

  newUser.save((err) => {
    if (err) {
      console.log(err);
      res.send("An error occurred while saving the data.");
    } else {
      res.send("Signup successful!");
    }
  });
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
