const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const https = require("https");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.get("/", function (req, res) {
    res.sendFile(path.join(__dirname, "public", "workout.html"));
});

app.post("/", function (req, res) {
    const exerciseQuery = req.body.exercise;
    const appid = "ibWQbv1br4Gb0pvgHID5aw==f1iO1EIKsloDqUyx";

    const url = `https://api.api-ninjas.com/v1/exercises?name=${exerciseQuery}`;

    const options = {
        headers: {
            "X-Api-Key": appid
        }
    };

    https.get(url, options, function (response) {
        let data = "";

        response.on("data", function (chunk) {
            data += chunk;
        });

        response.on("end", function () {
            const exercises = JSON.parse(data);

            if (exercises.length > 0) {
                const exercise = exercises[0];
                const name = exercise.name;
                const type = exercise.type;
                const muscle = exercise.muscle;
                const equipment = exercise.equipment;
                const difficulty = exercise.difficulty;
                const instructions = exercise.instructions;

                res.write("<p>Exercise Name: " + name + "</p>");
                res.write("<p>Type: " + type + "</p>");
                res.write("<p>Muscle: " + muscle + "</p>");
                res.write("<p>Equipment: " + equipment + "</p>");
                res.write("<p>Difficulty: " + difficulty + "</p>");
                res.write("<p>Instructions: " + instructions + "</p>");
            } else {
                res.write("<p>No exercises found for the given query.</p>");
            }
            res.send();
        });
    }).on("error", function (e) {
        console.error(e);
        res.send("An error occurred while fetching data.");
    });
});

app.listen(3001, () => {
    console.log("Server is running on port 3001");
});
